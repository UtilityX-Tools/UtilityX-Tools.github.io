# ----------------------------------------------------------------------------------------------------------------------------------------------------------|
# EN: 
#     - Do not touch or modify the code below. If there is an error, please contact the owner, but under no circumstances should you touch the code.
#     - Do not resell this tool, do not credit it to yours.
# FR: 
#     - Ne pas toucher ni modifier le code ci-dessous. En cas d'erreur, veuillez contacter le propriétaire, mais en aucun cas vous ne devez toucher au code.
#     - Ne revendez pas ce tool, ne le créditez pas au vôtre.

name_tool       =  "UtilityX"
type_tool       =  "Multi-Tools"
version_tool    =  "1.0"
coding_tool     =  "Python 3"
language_tool   =  "EN"
creator         =  "Muf4ld"
platform        =  "Windows 10/11 & Linux"
discord_server  =  "https://discord.gg/F9DFbPtf2u"
website         =  "https://utilityx-tools.github.io"
github_tool     =  "https://utilityx-tools.github.io"
telegram        =  "None"
